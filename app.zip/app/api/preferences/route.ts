import { NextResponse } from "next/server";
import type { NextRequest } from "next/server";

export interface DayHours {
  open: string;
  close: string;
  isClosed: boolean;
}

export interface CompanyPreferences {
  phone: string;
  email: string;
  address: {
    en: string;
    ar: string;
    fr: string;
  };
  gmapsEmbed: string;
  
  // Business Information
  businessInfo: {
    companyName: {
      en: string;
      ar: string;
      fr: string;
    };
    rcNumber: string;
    nifNumber: string;
    nisNumber: string;
    articleNumber: string;
  };

  // Social Media
  socialMedia: {
    facebook: string;
    linkedin: string;
    twitter: string;
    youtube: string;
  };

  // Business Hours of each day
  businessHours: {
    saturday: DayHours;
    sunday: DayHours;
    monday: DayHours;
    tuesday: DayHours;
    wednesday: DayHours;
    thursday: DayHours;
    friday: DayHours;
  };

  // Company Statistics
  statistics?: {
    provincesServed: string;
    officialProducts: string;
    businessPartners: string;
    averageResponse: string;
  };
}

let globalPreferences: CompanyPreferences = {
  phone: "0550 123 456",
  email: "contact@sti.dz",
  address: {
    en: "Lot 24, Zone Industrielle, Bab Ezzouar, Algiers, Algeria",
    ar: "المنطقة الصناعية رقم 24، باب الزوار، الجزائر العاصمة",
    fr: "Lot 24, Zone Industrielle, Bab Ezzouar, Alger, Algérie",
  },
  gmapsEmbed: "https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3197.876123456789!2d3.187654!3d36.726543!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x128fad123456789b%3A0x123456789abcdef!2sBab+Ezzouar!5e0!3m2!1sen!2sdz!4v1234567890123",
  
  businessInfo: {
    companyName: {
      en: "SARL Smart Technologie Innovation",
      ar: "ذ.م.م سمارت تكنولوجي إينوفيشين",
      fr: "SARL Smart Technologie Innovation",
    },
    rcNumber: "26/00-1234567B26",
    nifNumber: "001616091234567",
    nisNumber: "001616090012345",
    articleNumber: "16220123456",
  },

  socialMedia: {
    facebook: "https://facebook.com/sti.algeria",
    linkedin: "https://linkedin.com/company/sti-algeria",
    twitter: "https://twitter.com/sti_algeria",
    youtube: "https://youtube.com/@sti_algeria",
  },

  businessHours: {
    saturday: { open: "08:00", close: "17:00", isClosed: false },
    sunday: { open: "08:00", close: "17:00", isClosed: false },
    monday: { open: "08:00", close: "18:00", isClosed: false },
    tuesday: { open: "08:00", close: "18:00", isClosed: false },
    wednesday: { open: "08:00", close: "18:00", isClosed: false },
    thursday: { open: "08:00", close: "17:00", isClosed: false },
    friday: { open: "00:00", close: "00:00", isClosed: true },
  },

  statistics: {
    provincesServed: "58",
    officialProducts: "100%",
    businessPartners: "1000+",
    averageResponse: "24h",
  },
};

export async function GET() {
  return NextResponse.json(globalPreferences);
}

export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    globalPreferences = {
      phone: body.phone ?? globalPreferences.phone,
      email: body.email ?? globalPreferences.email,
      address: body.address ?? globalPreferences.address,
      gmapsEmbed: body.gmapsEmbed ?? globalPreferences.gmapsEmbed,
      businessInfo: body.businessInfo ?? globalPreferences.businessInfo,
      socialMedia: body.socialMedia ?? globalPreferences.socialMedia,
      businessHours: body.businessHours ?? globalPreferences.businessHours,
      statistics: body.statistics ?? globalPreferences.statistics,
    };
    return NextResponse.json({ success: true, preferences: globalPreferences });
  } catch {
    return NextResponse.json({ error: "Invalid preferences payload" }, { status: 400 });
  }
}
