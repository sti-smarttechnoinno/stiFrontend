import { NextResponse } from "next/server";
import type { NextRequest } from "next/server";

export interface TeamMemberTranslation {
  name: string;
  position: string;
}

export interface TeamMember {
  id: string;
  name: string;
  position: string;
  bio?: string;
  initials?: string;
  image?: string;
  linkedin?: string;
  translations?: {
    en?: TeamMemberTranslation;
    ar?: TeamMemberTranslation;
    fr?: TeamMemberTranslation;
  };
}

let globalTeamMembers: TeamMember[] = [
  {
    id: "1",
    name: "Karim Benali",
    position: "General Manager & Founder",
    initials: "KB",
    linkedin: "https://linkedin.com",
    translations: {
      en: { name: "Karim Benali", position: "General Manager & Founder" },
      ar: { name: "كريم بن علي", position: "المدير العام والمؤسس" },
      fr: { name: "Karim Benali", position: "Directeur Général & Fondateur" },
    },
  },
  {
    id: "2",
    name: "Yassine Mansouri",
    position: "Chief Commercial Officer",
    initials: "YM",
    linkedin: "https://linkedin.com",
    translations: {
      en: { name: "Yassine Mansouri", position: "Chief Commercial Officer" },
      ar: { name: "ياسين منصوري", position: "المدير التجاري الرئيسي" },
      fr: { name: "Yassine Mansouri", position: "Directeur Commercial" },
    },
  },
  {
    id: "3",
    name: "Amel Bouzid",
    position: "Director of Retail Partnerships",
    initials: "AB",
    linkedin: "",
    translations: {
      en: { name: "Amel Bouzid", position: "Director of Retail Partnerships" },
      ar: { name: "أمل بوزيد", position: "مديرة شراكات التجزئة" },
      fr: { name: "Amel Bouzid", position: "Directrice des Partenariats" },
    },
  },
  {
    id: "4",
    name: "Sofiane Hadj",
    position: "Head of Logistics & Supply",
    initials: "SH",
    linkedin: "",
    translations: {
      en: { name: "Sofiane Hadj", position: "Head of Logistics & Supply" },
      ar: { name: "سفيان حاج", position: "رئيس اللوجستيات والتزويد" },
      fr: { name: "Sofiane Hadj", position: "Chef Logistique & Approvisionnement" },
    },
  },
];

export async function GET() {
  return NextResponse.json(globalTeamMembers);
}

export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    if (Array.isArray(body)) {
      globalTeamMembers = body;
    } else if (body.members && Array.isArray(body.members)) {
      globalTeamMembers = body.members;
    }
    return NextResponse.json({ success: true, members: globalTeamMembers });
  } catch {
    return NextResponse.json({ error: "Invalid payload" }, { status: 400 });
  }
}
